<button class='primary-btn hover d-inline-flex align-items-center profil' style='margin-bottom: 2em; margin-right: 2em;'>
												<span class='mr-10'><a href='editer-profil.php'>Editer le profil</span><span class='lnr lnr-arrow-right'></span></a></button>

												


<button class='primary-btn hover d-inline-flex align-items-center profil' style='margin-bottom: 2em; margin-right: 2em;'>
<span class='mr-10'><a href='editer-profil.php'>Offrir ou rechercher Matériaux et/ou produits</span><span class='lnr lnr-arrow-right'></span></a></button>

<button class='primary-btn hover d-inline-flex align-items-center profil' style='margin-bottom: 2em; margin-right: 2em;'>
<span class='mr-10'><a href='editer-profil.php'>Offrir ou rechercher des services </span><span class='lnr lnr-arrow-right'></span></a></button>
<button class='primary-btn hover d-inline-flex align-items-center profil' style='margin-bottom: 2em; margin-right: 2em;'>
<span class='mr-10'><a href='forum.html'>Partagez vos expériences</span><span class='lnr lnr-arrow-right'></span></a></button>
													
<button type='button' class='genric-btn warning circle arrow profil'><a href='logout.php'>Se déconnecter <span class='lnr lnr-arrow-right'></span></a></button
---------------------------------------------------------------------------------------------------------------------------									

<a href="s'inscrire.html">Créer un compte</a>