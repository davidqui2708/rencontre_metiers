
<!DOCTYPE HTML>
<head>
<title>Free Movies Store Website Template | Home :: w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="stylesheet" href="css/linearicons.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/nice-select.css">
		<link rel="stylesheet" href="css/magnific-popup.css">
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="css/main.css">


	
</head>
<body>
	<div class="header">
		 <div class="headertop_desc">
			<div class="wrap">
				<div class="nav_list">
					<ul>
						<li><a href="../index.php">ACCUEIL</a></li>
						
					</ul>
				</div>

				

			
				<div class="account_desc "> 
						<ul>
							 <li><?php

						
							 
							echo "<div class='alert alert-success mt-4' role='alert'><strong>Bienvenu!</strong>  $nom				
							<button type='button' class='btn btn-info'><a href='connexion.php'>Se déconnecter</a></button></div>"
							?></li> 
							
						</ul>
					</div>

					<div id="openModal14" class="modalDialog">
						<div>
							<a href="#close" title="Close" class="close">X</a>
							<h4 class="modal-titre">CONNEXION</h4>
						
												<form action="check-connexion.php" method="post">                           	
													<div class="form-group">									
														<input type="email" class="form-control input-lg" name="email" placeholder="Email" required>        
													</div>							
													<div class="form-group">        
														<input type="password" class="form-control input-lg" name="password" placeholder="Password" required>       
													</div>								    
														<button type="submit" class="btn btn-success btn-block">Se connecter</button>
												</form>
												<!-- Collapse a form when user click Lost your password? link-->
												<p><a href="#showForm" data-toggle="collapse" aria-expanded="false" aria-controls="collapse">Mot de passe perdu?</a></p>	
												<div class="collapse" id="showForm">
													<div class='well'>
														<form action="recuperation-password.php" method="post">
															<div class="form-group">										
																<input type="email" class="form-control" name="email" placeholder="Saisissez l'email associé au mot de passe." required>
															</div>
															<button type="submit" class="btn btn-dark">Récupérer mot de passe</button>
														</form>								
													</div>
												</div>
																		
												<hr><p>Nouveau sur DqFilms? <a href="#openModal15" title="Create an account">Créer un compte</a>.</p>								
					
						</div>
					</div>
			
					<div id="openModal15" class="modalDialog">
						<div>
							<a href="#close" title="Close" class="close">X</a>
							<h4 class="modal-titre">S'INSCRIRE</h4>
							<div class="login-form">
								
							
								<form method="post" action="seveur/enregistrer_membre.php" method="POST">
									<div class="form-group">				
										<input type="text" class="form-control" name="nom" placeholder="Nom d'utilisateur" required>			
								  </div>
								  
								  <div class="form-group">				
										<input type="email" class="form-control" name="email" aria-describedby="emailHelp" placeholder="Email" required>
									</div>
								  
								  <div class="form-group">				
										<input type="password" class="form-control" name="password" placeholder="Mot de passe" required>
									</div>
								  
								  <button type="submit" class="btn btn-success btn-block">Créer un compte</button>
								</form>		

								

							</div>
						</div>
					</div>
			


				<div class="clear"></div>
			</div>
	  	</div>
  	  		<div class="wrap">
				<div class="header_top">
					<div class="logo">
						<a href="../index.php"><img src="../images/logo.png" alt="" /></a>
					</div>
						<div class="header_top_right">
						<div class="cart">
						  	   <p><a href="montrerPanier.php"><span>Panier</a></span><div id="dd" class=""> (<?php
							echo (empty($_SESSION['PANIER']))?0:count($_SESSION['PANIER']);
							?>)
						  	   <!-- 	<ul class="dropdown">
										<li>you have no items in your Shopping cart</li>
								</ul> --></div></p>
						  </div>
							  <div class="search_box">
					     		<form>
					     			<input type="text" value="Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}"><input type="submit" value="">
					     		</form>
					     	</div>
						 <div class="clear"></div>
					</div>
						  <script type="text/javascript">
								function DropDown(el) {
									this.dd = el;
									this.initEvents();
								}
								DropDown.prototype = {
									initEvents : function() {
										var obj = this;
					
										obj.dd.on('click', function(event){
											$(this).toggleClass('active');
											event.stopPropagation();
										});	
									}
								}
					
								$(function() {
					
									var dd = new DropDown( $('#dd') );
					
									$(document).click(function() {
										// all dropdowns
										$('.wrapper-dropdown-2').removeClass('active');
									});
					
								});
					    </script>
			 <div class="clear"></div>
  		</div>     
				<div class="header_bottom">
					<div class="header_bottom_left">				
					<div class="categories">
						   <ul>
						   <h3>CATÉGORIES</h3>
							      <li><a href="categories/catAventure.php">Aventure</a></li>
							      <li><a href="categories/catAction.php">Action</a></li>
							      <li><a href="categories/catDrame.php">Drame</a></li>
							      <li><a href="categories/catComedie.php">Comedie</a></li>
							      <li><a href="categories/catEnfants.php">Enfants</a></li>
	
						  	 </ul>
							</div>			
		  	         </div>
						    <div class="header_bottom_right">	
								
							
							<?php
			include "BD/connexion.inc.php";
			
			$email = $_POST['email'];				/* 
			$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
 */
			// Check connection
			if (!$connexion) {
				die("Connection failed: " . mysqli_connect_error());
			}
				
			$sql = "SELECT Email, Password FROM membres WHERE Email='$email'";				
			$result = mysqli_query($connexion, $sql);
				
			if (mysqli_num_rows($result) > 0) {				
				$row = mysqli_fetch_assoc($result);
				
				$subject = "Your password for PHP Login";
				$body = "Your password is:" . $row['Password'];
				
				$headers = 'From: youremail@mail.com' . "\r\n" .
				'Reply-To: youremail@mail.com' . "\r\n" .
				'X-Mailer: PHP/' . phpversion();
				
				mail($email, $subject, $body, $headers);				
				
				echo "<div class='alert alert-success alert-dismissible mt-4' role='alert'>
				<button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				<span aria-hidden='true'>&times;</span></button>

				<p>Email was send! Please check your email.</p>
				<p><a class='alert-link' href=connexion.php>Login</a></p></div>";
			} else {
				echo "We are sorry, but that email is not in our data base.";
			}
			?>

   

						<!------End Slider ------------>
			         </div>
			     <div class="clear"></div>
			</div>
   		</div>
   </div>
   <!------------End Header ------------>
 
</div>

	
	
	
