




<!DOCTYPE html>
<html lang="zxx" class="no-js">
<head>
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/fav.png">
	<!-- Author Meta -->
	<meta name="author" content="Colorlib">
	<!-- Meta Description -->
	<meta name="description" content="">
	<!-- Meta Keyword -->
	<meta name="keywords" content="">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Layal</title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,500,600" rel="stylesheet">
		<!--
		CSS
		============================================= -->
		<link rel="stylesheet" href="css/linearicons.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/nice-select.css">
		<link rel="stylesheet" href="css/magnific-popup.css">
		<link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css" integrity="sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc" crossorigin="anonymous">
		<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
			

	</head>
	<body>
		<?php
				session_start();
				if (isset($_SESSION['loggedin'])) {  
				}
				else {
					echo "<div class='alert alert-danger mt-4' role='alert'>
					<h4> Vous devez vous connecter pour accéder à cette page.</h4>
					<b><a href='login.html'>Connectez-vous ici!</a></b></div>";
					exit;
				}
				// checking the time now when check-login.php page starts
				$now = time();           
				if ($now > $_SESSION['expire']) {
					session_destroy();
					echo "<div class='alert alert-danger mt-4' role='alert'>
					<h4>Votre session a expiré!</h4>
					<b><a href='login.html'>Connectez-vous ici</a></b></div>";
					exit;
					}
		?>
        <?php
    
			include "BD/connexion.inc.php";

			$user_check = $_SESSION['id'];

			$ses_sql = mysqli_query($connexion,"SELECT * FROM membres WHERE Id = '$user_check' ");

			$row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);

			$id = $row['Id'];
			$login_session = $row['Email'];
			$nom = $row['Nom'];
			$prenom = $row['Prenom'];

			if(!isset($_SESSION['id'])){
				header("location:login.html");
			}
		?>
                                
		<div class="main-wrapper-first">
			<div class="hero-area relative">

				
				<header>
					<div class="container">
						
						
						<div class="header-wrap">
							<div class="header-top d-flex justify-content-between align-items-center">
								
								<div class="logo">
									<a href="index.php"><img src="img/logo.png" alt=""></a>
								</div>
							
								<div class="main-menubar d-flex align-items-center">
									<nav class="hide">
										<a href="index.php">Home</a>
										<a href="generic.html">Matériaux ou produits</a>
										<a href="elements.html">Services ou emplois</a>
										<a href="forum.html">Forums</a>
									</nav>

									<nav class="login">
										<a href="#">profil de <b><?php echo $row ['Prenom']?></b> </a>
										<a href='logout.php'>Se déconnecter</a>
										
									</nav>
									<d<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
								</div>
							</div>
						</div>
					</div>
				</header>
			</div>
		</div>
		<div class="main-wrapper">
			<!-- Start banner Area -->
			<div class="banner-area">
				<div class="container">
					<div class="row justify-content-center align-items-center">
						<div class="col-lg-4 col-md-6 col-sm-12">
							<img class="img-fluid mx-auto d-flex" src="img/header-img.png" alt="">
						</div>
						<div class="col-lg-6 col-md-6 col-sm-12 pb-40">
							<div class="banner-content">



<div class="well">
    <ul class="nav nav-tabs">
		<li class="active"><a href="#home2" data-toggle="tab">Profil</a></li>
        <li class=""><a href="#home" data-toggle="tab">Mise a jour</a></li>
        <li><a href="#profile" data-toggle="tab">Annonces</a></li>
	</ul>
	
	

   


    <div id="myTabContent" class="tab-content">
      <div class="tab-pane active in" id="home2">
		 
	 	<ul class="list-group ">
			<li class="list-group-item"><strong>Nom:</strong> &nbsp; <b><?php echo $row ['Nom']?></b></li>
			<li class="list-group-item"><strong>Prenom:</strong>&nbsp; <b><?php echo $row ['Prenom']?></b></li>
			<li class="list-group-item"><strong>Email:</strong>&nbsp; <b><?php echo $row ['Email']?></b></li>
			<li class="list-group-item"><strong>Telephone:</strong>&nbsp; <b><?php echo $row ['Telephone']?></b></li>
			<li class="list-group-item"><strong>Metier:</strong>&nbsp; <b><?php echo $row ['Metier']?></b></li>
			<li class="list-group-item"><strong>Ville:</strong>&nbsp; <b><?php echo $row ['Ville']?></b></li>
		</ul>

				
				
			
	  </div>
	  <div class="tab-pane  in" id="home">
			<form method="post" action="update_membre.php" id="tab">
				   
				<ul class="list-group ">
					<li class="list-group-item"><strong>Nom:</strong> &nbsp; <input style="width:100%;height:40px"  type="text" name="nom" value="<?php echo $row ['Nom']?>"></li>
					<li class="list-group-item"><strong>Prenom:</strong>&nbsp; <input style="width:100%;height:40px" type="text" name="prenom" value="<?php echo $row ['Prenom']?>"></li>
					<li class="list-group-item"><strong>Email:</strong>&nbsp; <input style="width:100%;height:40px" type="text" name="email" value="<?php echo $row ['Email']?>"></li>
					<li class="list-group-item"><strong>Telephone:</strong>&nbsp; <input style="width:100%;height:40px" type="text" name="telephone" value="<?php echo $row ['Telephone']?>"></li>
					<li class="list-group-item"><strong>Metier:</strong>&nbsp; <input style="width:100%;height:40px" type="text" name="metier" value="<?php echo $row ['Metier']?>"></li>
					<li class="list-group-item"><strong>Ville:</strong>&nbsp; <input style="width:100%;height:40px" type="text" name="ville" value="<?php echo $row ['Ville']?>"></li>
					<li> <br>				
						<button value="" type="submit" class="primary-btn hover d-inline-flex align-items-center ns"><span class="mr-10">Mettre à jour</span><span class='lnr lnr-arrow-right'></span></button>
					
					</li>
				</ul>

			</form>
      </div>

   

      <div class="tab-pane fade" id="profile">
    	<form id="tab2">
        	Annonces<
			<input type="text" name="annonces" value="<?php echo $row ['Annonces']?>" class="input-xlarge">
        	<div>
        	    <button class="btn btn-primary">Update</button>
        	</div>
    	</form>
      </div>
  </div>

							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End banner Area -->
			
			<div id="openModal14" class="modalDialog">
				<div class="md">
					<a href="#close" title="Close" class="close">X</a>
					<h4 class="modal-titre">Connexion</h4>
				
										<form action="check-connexion.php" method="post">                           	
											<div class="form-group">									
												<input type="email" class="form-control input-lg" name="email" placeholder="Email" required>        
											</div>							
											<div class="form-group">        
												<input type="password" class="form-control input-lg" name="password" placeholder="Password" required>       
											</div>								    
											<button class="primary-btn hover d-inline-flex align-items-center" style="width:100%;margin-bottom: 2em;" class="mr-10" style="
												margin-left: 7em;">Se connecter<span class='lnr lnr-arrow-right'></span><</button>
										</form>
										<!-- Collapse a form when user click Lost your password? link-->
										<b style="text-align: center;"><a href="#showForm" data-toggle="collapse" aria-expanded="false" aria-controls="collapse" style="
											color: #111;
										" class="collapsed">Mot de passe perdu?</a></b>	
										<div class="collapse" id="showForm">
											<div class="well">
												<form action="viewsfilms/recuperation-password.php" method="post">
													<div class="form-group">										
														<input type="email" class="form-control" name="email" placeholder="Saisissez l'email associé au mot de passe." required>
													</div>
													<button type="submit" class="btn btn-dark rec">Récupérer mot de passe</button>
												</form>								
											</div>
										</div>
																
										<hr><b class="txpop">Vous n'avez pas encore de compte? <a href="s'inscrire.html" title="Create an account">Créez-en un ici</a>.</b>								
			
				</div>
			</div>

		
		
			
			<!-- Start Footer Section -->
			<footer class="footer-area pt-100 pb-20">
				<div class="container">
					<div class="row">
						
						
						
						
					</div>
					<div class="footer-bottom d-flex justify-content-between align-items-center flex-wrap">
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						<b class="footer-text m-0">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></b>
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
					</div>
				</div>
			</footer>
			<!-- End Footer Section -->
		</div>
		<script src="js/vendor/jquery-2.2.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="js/vendor/bootstrap.min.js"></script>
		<script src="js/jquery.ajaxchimp.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/jquery.nice-select.min.js"></script>
		<script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/main.js"></script>
        
	</body>
</html>
