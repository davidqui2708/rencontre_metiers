
<!DOCTYPE html>
<html lang="fr_ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>rencontres - annonces</title>
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="./bootstrap-4.5.2-dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./bootstrap-4.5.2-dist/css/bootstrap.min.css">
    <link href="src/simple-upload.scss">
    <script src="dist/jquery-simple-upload.js"></script>
    <style>
    .dropZone {
      width: 300px;
      height: 100px;
      border: 1px solid #ccc;
      text-align: center;
      margin: 5px;
    }
    #basic_message {
      height: fit-content;
      /*overflow-y: scroll;*/
    }
    .simple-upload-dragover {
     background-color: #eef;
  }
   .simple-upload-filename {
     margin-right: 0.5em;
  }
  
    </style>
  </head>