



<?php
require_once("./model/annoncesModel.inc.php");
session_start();

$titre_annonce = "titre_";//titre de l'annonce de l'usager
$username = $_SESSION["prenom"]."_"; //nom de l'usager
//$folder = "tagne";
$file_name = $username.$titre_annonce;
$last_insert_id = $_SESSION['last_insert_id'];
$idannonces = $_SESSION['idannonces'];
$target = "./uploads/";
$idmembres =  $_SESSION["idmembres"];
$sources = "annonces";//les fichiers sont ceux des annonces
$now = new DateTime('NOW');
$a = get_object_vars($now);
$date_created = $a["date"];

//envoyer fichier au serveur
move_uploaded_file($_FILES["fichier1"]["tmp_name"],
    $target.$sources."_".$idannonces."_".$idmembres."_".$_FILES["fichier"]["name"][0]  
);

function insert_fichier(){
     try{
        $requete="INSERT INTO fichiers VALUES(0,?,?,?,?)";

            $tabDonnees = [$file_name,$date_created,$sources,$idmembres];
            $unModele = new annoncesModel($requete,$tabDonnees );
            //$stmt = $unModele->executer();
            $tabRes['action']="post_fichier";
            $tabRes['ok']="Votre annonce est bien mise à jour.";
            $tabRes['current_user_id'] =  $unModele->lastInsertId();
    }catch(PDOException $e){
        $Log['error'] = [$e->getMessage()];
        $tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
        echo $e->getMessage();
    }finally{
        unset($unModele);
        unset($stmt);
    }
}


function insert_fichier_update(){
    
    try{
        
        $requete="UPDATE annonces SET titre=?,message=?, type_annonces=?, type_action=?, lieu=? WHERE idmembres = $user_id AND idannonces=$idannonces";

            $tabDonnees = [$titre,$message,$type_annonces,$type_action,$lieu];
            $unModele = new annoncesModel($requete,$tabDonnees );
            $stmt = $unModele->executer();
            $tabRes['action']="update";
            $tabRes['ok']="Votre annonce a bien été mise à jour. Merci pour votre participation.";
            $tabRes['current_user_id'] =  $unModele->lastInsertId();
    }catch(PDOException $e){
        $Log['error'] = [$e->getMessage()];
        $tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
        echo $e->getMessage();
    }finally{
        unset($unModele);
        unset($stmt);
        header("Location:index.php");
    }

}


  
  

   // echo "Stored in: " . "uploads/" . $_FILES["files"]["name"];
 