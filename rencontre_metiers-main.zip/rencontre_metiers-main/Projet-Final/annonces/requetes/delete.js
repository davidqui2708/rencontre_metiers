

//enregistrer  
function effacer(id){
	var form = new FormData();//document.getElementById(formId)
    //form.append('action',formId);
    
		//console.log("retour = " + valider(formId));
    //if(val = valider(formId))
    {
		//console.log("retour = " + val);
		$.ajax({
			type : 'POST',
			url : './delete.php?id='+id,
			data : form,
			dataType : 'json', //text pour le voir en format de string
			async : true,
			cache : false,
			contentType : false,
			processData : false,
			success : function (reponse){
				//alert(reponse);
				var msg="";
				if(reponse.ok ){
					msg = reponse.ok;
					$("#"+formId+" input[type=text]").each(function(index,valeur){
						valeur.value="";
					});
					$("#msg").css("color","green");
					msg += "<br>"+reponse.msg_video;
					msg += "<br>"+reponse.msg_image;
					msg += "<br>"+reponse.msg_doc;
				}else{
					msg = reponse.error;
					msg += "<br>"+reponse.msg_video;
					msg += "<br>"+reponse.msg_image;
					$("#msg").css("color","red");
					alert(msg);
				}
				$("#msg").html(msg);
				alert(msg);
				setTimeout(function(){
					$("#msg").html("");
				},5000);
				
			},
			fail : function (err){
				$("#msg").html(err);
			}
		});
	}
}

