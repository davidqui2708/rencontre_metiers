<!DOCTYPE html>
<html lang="zxx" class="no-js">
<head>
	
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/fav.png">
	<!-- Author Meta -->
	<meta name="author" content="Colorlib">
	<!-- Meta Description -->
	<meta name="description" content="">
	<!-- Meta Keyword -->
	<meta name="keywords" content="">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Layal</title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,500,600" rel="stylesheet">
		<!--
		CSS
		============================================= -->
		<link rel="stylesheet" href="../css/linearicons.css">
		<link rel="stylesheet" href="../css/owl.carousel.css">
		<link rel="stylesheet" href="../css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/nice-select.css">
		<link rel="stylesheet" href="../css/magnific-popup.css">
		<link rel="stylesheet" href="../css/bootstrap.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css" integrity="sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc" crossorigin="anonymous">
		
			

	</head>
	<body>
		<div class="main-wrapper-first">
			<div class="hero-area relative">

				
				<header>
					<div class="container">
						
						
						<div class="header-wrap">
							<div class="header-top d-flex justify-content-between align-items-center">
								
								<div class="logo">
									<a href="../index.html"><img src="../img/logo.png" alt=""></a>
								</div>
							
								<div class="main-menubar d-flex align-items-center">
									<nav class="hide">
										<a href="../index.html">Home</a>
										<a href="../generic.html">Matériaux ou produits</a>
										<a href="./">Services ou emplois</a>
										<a href="../forum.html">Forums</a>
									</nav>

									<nav class="login">
										<a href="../s'inscrire.html">Créer un compte</a>
										<a href="../index.html#openModal14">Se connecter</a>
										
									</nav>
									<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
								</div>
							</div>
						</div>
					</div>
				</header>
			</div>
		</div>
        <div class="main-wrapper">
			<!-- Start banner Area -->
			<div class="banner-area">
				<div class="container">
					<div class="section-top-border">
<?php
    require_once("./model/annoncesModel.inc.php");
    session_start();
    include('./header.php');
    $idmembres = $_SESSION['idmembres'];


    //affiche chaque card
    function affiche_card($donnee){
        
        global $idmembres;
        $card = "<div class=\"card\">\n";
        $card.= "  <h5 class=\"card-header\">$donnee->titre : $donnee->type_annonces à $donnee->type_action</h5>\n";
        $card.= "  <div class=\"card-body\">\n";
        $card.= "    <h5 class=\"card-title\"> $donnee->type_annonces </h5>\n";
        $card.= "    <h6 class=\"card-text\">Adresse : $donnee->lieu</h6>\n";
        $card.= "    <div class=\"card-text\" '>";

        $card.="<p>\n";
        $card.="  <a class=\"btn btn-primary\" data-toggle=\"collapse\" href=\"#collapseExample$donnee->idannonces\" role=\"button\" aria-expanded=\"false\" aria-controls=\"collapseExample\">\n";
        $card.="    Voir plus\n";
        $card.="  </a>\n";
        $card.="</p>\n";
        $card.="<div class=\"collapse\" id=\"collapseExample$donnee->idannonces\">\n";
        $card.="  <div class=\"card card-body\">\n";
        $card.= "       $donnee->message\n";
        $card.= "       <div>". affiches($donnee)."</div>\n";
        $card.="  </div>\n";
        $card.="</div>";
    
        $card.= "    </div>\n";
        $card.= "  </div>\n";
        $card.= "    <p class=\"card-text\">Publiée le : $donnee->date</p>\n";
        $card.= "    <div style='display:inline'><a href=\"./annonce.php?id=$donnee->idannonces\" class=\"btn btn-secondary\">Détails</a>";
        if($idmembres > 0) {
            $card.= "    <form onsubmit='return effacer($donnee->idannonces)' ><input type='submit' class=\"btn btn-danger\" value='Effacer'></form>";
            $card.= "    <form action='./annonce_update.php' method='post'> <input type='hiddden' name='idannonces' id='idannonces' value=$donnee->idannonces hiddden=true style='display:none'>";
            $card.= "    <input type='submit' class=\"btn btn-primary\" value='Modifier'></form>";
        }
        $card.= "  </div>\n";
        $card.= "</div>\n<br>";
        return $card;
    }


    //affiche les fichiers joints à l'annonce
    function affiches($fichiers){
        $content = "<div >";
        
            $content.=lefichier($fichiers->fichier1);
            $content.=lefichier($fichiers->fichier3);
            $content.=lefichier($fichiers->fichier2);
        
        $content.= "</div>";
        return $content;
    }

    //selectionne les fichiers joints à l'annonce
    function lefichier($data){
        $extension=strrchr($data,'.');
        
        $affiche="";
        if(strpos($extension, ".doc") > -1 || strpos($extension, ".docx") > -1 || strpos($extension, ".pdf") > -1){
            $affiche = "<br><div><a href=./uploads/docs/$data >$data </a></div>";
            return $affiche;
        }
        else
        if( strpos($extension, ".mp4") > -1){
            $affiche = "<video width=\"320\" height=\"240\" controls><source src=./uploads/videos/$data type='video/mp4' ></video>";
            return $affiche;
        }else 
        if(strpos($extension, ".jpg") > -1 || strpos($extension, ".jpeg") > -1 || strpos($extension, ".png") > -1){
            $affiche = "<img src=./uploads/photos/$data width=\"320\" height=\"240\" alt=image>";
            return $affiche;
        } 
    }


        //liste de tous les annonces enregistrées
        function liste(){
            global $tabRes,$idmembres;

            $req = "SELECT * FROM annonces WHERE idmembres=$idmembres ORDER BY idannonces DESC";
            
            $unModele = new annoncesModel($req);//
            $sth = $unModele->executer();
        
            $count=0;

            echo "<div class='container'>";
            while( $row = $sth->fetch( PDO::FETCH_OBJ)  ){
                echo affiche_card($row);
                //$tabRes['liste'][$count++] = $row;
            }
            echo "</div>";
            
            unset($sth);
            unset($unModele);
        
        }
        
        liste();

    ?>

                    </div> 
                </div> 
            </div> 
        </div>
		<script src="../js/vendor/jquery-2.2.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="../js/vendor/bootstrap.min.js"></script>
		<script src="../js/jquery.ajaxchimp.min.js"></script>
		<script src="../js/owl.carousel.min.js"></script>
		<script src="../js/jquery.nice-select.min.js"></script>
		<script src="../js/jquery.magnific-popup.min.js"></script>
        <script src="../js/main.js"></script>
        <script src="./requetes/delete.js"></script>
        
        
	</body>
</html>