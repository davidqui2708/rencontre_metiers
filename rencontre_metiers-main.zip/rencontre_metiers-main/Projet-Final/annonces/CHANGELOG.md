# CHANGELOG

## 0.4.0

* Add `ajax` option and integrate some options (`headers`, `dataType`, `timeout`, `async`) to it.

## 0.3.0

* Bundle css with js.

## 0.2.0

* Support callback for query parameters.
* Fix event namespace.

## 0.1.0

* First release.
