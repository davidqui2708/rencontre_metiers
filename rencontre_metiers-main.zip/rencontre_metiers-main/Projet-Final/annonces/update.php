
<?php
   
    require_once("./model/annoncesModel.inc.php");
    $tabRes = array();

    function epurerDonnees($donnees){
        $donnees = trim($donnees);
        //str_replace("/","",$data);
        $donnees = stripslashes($donnees);
        $donnees = htmlspecialchars($donnees);
        return $donnees;
    }
	
    //create une annonce
    function update(){ 
        global $tabRes;
		
        
            //if(isset($_POST['submit'])){
                $titre = epurerDonnees( $_POST['titre']);
                //$idmetier =  epurerDonnees( $_POST['idmetiers']);
                $message=  epurerDonnees( $_POST['message']);
                $type_annonces =  epurerDonnees( $_POST['type_annonces']);
                $user_id =  epurerDonnees( $_POST['idmembres']);
                $type_action=  epurerDonnees( $_POST['type_action']);
                $lieu=  epurerDonnees( $_POST['lieu']);
                $idannonces=  epurerDonnees( $_POST['idannonces']);
                //$nombrevues=  0;
                $now = new DateTime('NOW');
                //print_r($now);
                echo "<br>";
                $a = get_object_vars($now);
                $createddate = $a["date"];
                //print_r($createddate);
                echo "<br>";
            try{
                //$requete="INSERT INTO annonces VALUES(0,?,?,?,?,?,?,?,?,?)";
                $requete="UPDATE annonces SET titre=?,message=?, type_annonces=?, type_action=?, lieu=? WHERE idmembres = $user_id AND idannonces=$idannonces";

                    //envoyer les fichiers

                    $tabDonnees = [$titre,$message,$type_annonces,$type_action,$lieu];
                    $unModele = new annoncesModel($requete,$tabDonnees );
                    $stmt = $unModele->executer();
                    $tabRes['action']="update";
                    $tabRes['ok']="Votre annonce est bien été mise à jour. Merci pour votre participation.";
                    //$tabRes['current_user_id'] =  $unModele->lastInsertId();
            }catch(PDOException $e){
                $Log['error'] = [$e->getMessage()];
                $tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
				echo $e->getMessage();
			}finally{
                unset($unModele);
                unset($stmt);
                header("Location:mes_annonces.php");
            }
       // }

    } //Fin create annonce

	update();
echo json_encode($tabRes);
    //******************************************************

