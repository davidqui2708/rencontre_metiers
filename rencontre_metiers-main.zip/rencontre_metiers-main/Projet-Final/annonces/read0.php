<?php
require_once("./model/annoncesModel.inc.php");

$idmembres = $_SESSION['idmembres'];

function lefichier($data){
    $extension=strrchr($data,'.');
    
    $affiche="";
    if(strpos($extension, ".doc") > -1 || strpos($extension, ".docx") > -1 || strpos($extension, ".pdf") > -1){
        $affiche = "<br><div><a href=./uploads/docs/$data >$data </a></div>";
        return $affiche;
    }
    else
    if( strpos($extension, ".mp4") > -1){
        $affiche = "<video width=\"320\" height=\"240\" controls><source src=./uploads/videos/$data type='video/mp4' ></video>";
        return $affiche;
    }else 
    if(strpos($extension, ".jpg") > -1 || strpos($extension, ".jpeg") > -1 || strpos($extension, ".png") > -1){
        $affiche = "<img src=./uploads/photos/$data width=\"320\" height=\"240\" alt=image>";
        return $affiche;
    } 
}

function affiches($fichiers){
    $content = "<div >";
    
        $content.=lefichier($fichiers->fichier1);
        $content.=lefichier($fichiers->fichier3);
        $content.=lefichier($fichiers->fichier2);
    
    $content.= "</div>";
    return $content;
}


function affiche_card($donnee){
    global $idmembres;
    $card = "<div class=\"card\">\n";
    $card.= "  <h5 class=\"card-header\">$donnee->titre : $donnee->type_annonces à $donnee->type_action</h5>\n";
    $card.= "  <div class=\"card-body\">\n";
    $card.= "    <h5 class=\"card-title\"> $donnee->type_annonces </h5>\n";
    $card.= "    <p class=\"card-text\">$donnee->lieu</p>\n";
    $card.= "    <div class=\"card-text\" '>";
    $card.= "       <div>$donnee->message</div>\n"; 
    $card.= "       <div>". affiches($donnee)."</div>\n";
    $card.= "    </div>\n";
    $card.= "  </div>\n";
    $card.= "    <p class=\"card-text\">Publiée le : $donnee->date</p>\n";
    $card.= "    <div><a href=\"./annonce.php?id=$donnee->idannonces\" class=\"btn btn-secondary\">Détails</a>";
    if($idmembres > 0) {
        $card.= "    <span class=\"btn btn-danger\" onclick='effacer($donnee->idannonces)' >Effacer</span>";
        $card.= "    <form action='./annonce_update.php' method='post'> <input type='hiddden' name='idannonces' id='idannonces' value=$donnee->idannonces hiddden=true style='display:none'>";
        $card.= "    <input type='submit' class=\"btn btn-primary\" value='Modifier'></form>";
    }
    $card.= "  </div>\n";
    $card.= "</div>\n<br>";
    return $card;
}

    //liste de tous les annonces enregistrés
    function liste(){
        global $tabRes, $idmembres;

        if( $idmembres > 0){
            $req = "SELECT * FROM annonces WHERE idmembres=$idmembres";
        }else{
            $req = "SELECT * FROM annonces ";
        }
        
        $unModele = new annoncesModel($req);//,[$categ]
        $sth = $unModele->executer();
       
        $count=0;
        while( $row = $sth->fetch( PDO::FETCH_OBJ)  ){
            echo affiche_card($row);
            //$tabRes['liste'][$count++] = $row;
        }
        
        unset($sth);
        unset($unModele);
       
    }
    
    liste();

    ?>
<script src="./requetes/delete.js"></script>