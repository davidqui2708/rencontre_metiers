export const NAMESPACE = 'simple-upload';
