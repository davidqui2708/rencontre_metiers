




<!DOCTYPE html>
<html lang="zxx" class="no-js">
<head>
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/fav.png">
	<!-- Author Meta -->
	<meta name="author" content="Colorlib">
	<!-- Meta Description -->
	<meta name="description" content="">
	<!-- Meta Keyword -->
	<meta name="keywords" content="">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Layal</title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,500,600" rel="stylesheet">
		<!--
		CSS
		============================================= -->
		<link rel="stylesheet" href="css/linearicons.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/nice-select.css">
		<link rel="stylesheet" href="css/magnific-popup.css">
		<link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css" integrity="sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc" crossorigin="anonymous">
		<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
			

	</head>
	<body>

       
                                
		<div class="main-wrapper-first">
			<div class="hero-area relative">

				
				<header>
					<div class="container">
						
						
						<div class="header-wrap">
							<div class="header-top d-flex justify-content-between align-items-center">
								
								<div class="logo">
									<a href="index.html"><img src="img/logo.png" alt=""></a>
								</div>
							
								<div class="main-menubar d-flex align-items-center">
									<nav class="hide">
										<a href="index.html">Home</a>
										<a href="generic.html">Matériaux ou produits</a>
										<a href="elements.html">Services ou emplois</a>
										<a href="forum.html">Forums</a>
									</nav>

									<nav class="login">
										<a href="inscription.html">Créer un compte</a>
										<a href="#openModal14">Se connecter</a>
										
									</nav>
									<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
								</div>
							</div>
						</div>
					</div>
				</header>
			</div>
		</div>
		<div class="main-wrapper">
			<!-- Start banner Area -->
			<div class="banner-area">
				<div class="container">
					<div class="row justify-content-center align-items-center">
						<div class="col-lg-4 col-md-6 col-sm-12">
							<img class="img-fluid mx-auto d-flex" src="img/header-img.png" alt="">
						</div>
						<div class="col-lg-6 col-md-6 col-sm-12 pb-40">
							<div class="banner-content">



<div class="well">
    <ul class="nav nav-tabs">
      <li class="active"><a href="#home" data-toggle="tab">Profil de membre</a></li>
      <li><a href="#profile" data-toggle="tab">Annonces</a></li>
	</ul>
	
	<?php
	session_start();
    if (isset($_SESSION['loggedin'])) {  
    }
    else {
        echo "<div class='alert alert-danger mt-4' role='alert'>
        <h4> Vous devez vous connecter pour accéder à cette page.</h4>
        <p><a href='login.html'>Connectez-vous ici!</a></p></div>";
        exit;
    }
    // checking the time now when check-login.php page starts
    $now = time();           
    if ($now > $_SESSION['expire']) {
        session_destroy();
        echo "<div class='alert alert-danger mt-4' role='alert'>
        <h4>Votre session a expiré!</h4>
        <p><a href='login.html'>Connectez-vous ici</a></p></div>";
        exit;
        }
    ?>

    <?php
    
    include "BD/connexion.inc.php";

	$user_check = $_SESSION['id'];

   $ses_sql = mysqli_query($connexion,"SELECT * FROM membres WHERE Id = '$user_check' ");

   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);

   $id = $row['Id'];
   $login_session = $row['Email'];
   $nom = $row['Nom'];
   $prenom = $row['Prenom'];

   if(!isset($_SESSION['id'])){
      header("location:login.html");
   }
?>


    <div id="myTabContent" class="tab-content">
      <div class="tab-pane active in" id="home">
        <form method="post" action="update_membre.php" id="tab">
            <label>Nom</label>
            <input type="text" name="nom" value="<?php echo $row ['Nom']?>" class="input-xlarge">
            <label>Prenom</label>
            <input type="text" name="prenom" value="<?php echo $row ['Prenom']?>" class="input-xlarge">
            <label>Email</label>
            <input type="text" name="email" value="<?php echo $row ['Email']?>" class="input-xlarge">
            <label>Mot de passe</label>
            <input type="password" name="password" value="<?php echo $row ['Password']?>" class="input-xlarge">
            <label>Adresse</label>
            <textarea  name="adresse" value="<?php echo $row ['Adresse']?>" rows="3" class="input-xlarge">
			</textarea>
			<label>Téléphone</label>
            <input type="text" name="telephone" value="<?php echo $row ['Telephone']?>" class="input-xlarge">
            
           

            <!--Google map-->
<div id="map-container-google-1" class="z-depth-1-half map-container">
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d357139.2707120841!2d-73.3620509!3d45.6277118!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cc91a541c64b70d%3A0x654e3138211fefef!2zTW9udHLDqWFsLCBRQw!5e0!3m2!1sfr!2sca!4v1602462438574!5m2!1sfr!2sca" width="300" height="225" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
</div>



<!--Google Maps-->
           
           
          	<div>
              <button type="submit" class="primary-btn hover d-inline-flex align-items-center mj"><span class="mr-10">Mettre à jour</span><span class="lnr lnr-arrow-right"></span></button>
			  <button type='button' class='genric-btn warning circle arrow profil'><a href='logout.php'>Se déconnecter <span class='lnr lnr-arrow-right'></span></a></button>
			</div>
			
			
        </form>
      </div>

   

      <div class="tab-pane fade" id="profile">
    	<form id="tab2">
        	<label>Annonces</label>
			<input type="text" name="annonces" value="<?php echo $row ['Annonces']?>" class="input-xlarge">
        	<div>
        	    <button class="btn btn-primary">Update</button>
        	</div>
    	</form>
      </div>
  </div>

							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End banner Area -->
			
			<div id="openModal14" class="modalDialog">
				<div class="md">
					<a href="#close" title="Close" class="close">X</a>
					<h4 class="modal-titre">Connexion</h4>
				
										<form action="check-connexion.php" method="post">                           	
											<div class="form-group">									
												<input type="email" class="form-control input-lg" name="email" placeholder="Email" required>        
											</div>							
											<div class="form-group">        
												<input type="password" class="form-control input-lg" name="password" placeholder="Password" required>       
											</div>								    
											<button class="primary-btn hover d-inline-flex align-items-center" style="width:100%;margin-bottom: 2em;"><span class="mr-10" style="
												margin-left: 7em;
											">Se connecter</span><span class="lnr lnr-arrow-right"></span></button>
										</form>
										<!-- Collapse a form when user click Lost your password? link-->
										<p style="text-align: center;"><a href="#showForm" data-toggle="collapse" aria-expanded="false" aria-controls="collapse" style="
											color: #111;
										" class="collapsed">Mot de passe perdu?</a></p>	
										<div class="collapse" id="showForm">
											<div class="well">
												<form action="viewsfilms/recuperation-password.php" method="post">
													<div class="form-group">										
														<input type="email" class="form-control" name="email" placeholder="Saisissez l'email associé au mot de passe." required>
													</div>
													<button type="submit" class="btn btn-dark rec">Récupérer mot de passe</button>
												</form>								
											</div>
										</div>
																
										<hr><p class="txpop">Vous n'avez pas encore de compte? <a href="s'inscrire.html" title="Create an account">Créez-en un ici</a>.</p>								
			
				</div>
			</div>

		
		
			
			<!-- Start Footer Section -->
			<footer class="footer-area pt-100 pb-20">
				<div class="container">
					<div class="row">
						
						
						
						
					</div>
					<div class="footer-bottom d-flex justify-content-between align-items-center flex-wrap">
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						<p class="footer-text m-0">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
					</div>
				</div>
			</footer>
			<!-- End Footer Section -->
		</div>
		<script src="js/vendor/jquery-2.2.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="js/vendor/bootstrap.min.js"></script>
		<script src="js/jquery.ajaxchimp.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/jquery.nice-select.min.js"></script>
		<script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/main.js"></script>
        
	</body>
</html>
