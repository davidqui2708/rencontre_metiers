<?php
	include("../BD/connexion.inc.php");
	
	if(isset($_POST["submit"])){
		if(!empty($_POST['mensaje'])){
			$autor=$_POST['autor'];
			$titulo=$_POST['titulo'];
			$mensaje=$_POST['mensaje'];
			$respuestas=$_POST['respuestas'];
			$identificador=$_POST['identificador'];
			$fecha = date("y-m-d");
			
			
			//Evitamos que el usuario ingrese HTML
			$mensaje = htmlentities($mensaje);
			echo "identificador:";
			echo $identificador;
			
			//Grabamos el mensaje en la base de datos.
			$query = "INSERT INTO forum (autor, titulo, mensaje, identificador, fecha, ult_respuesta) VALUES ('$autor', '$titulo', '$mensaje', '$identificador','$fecha','$fecha')";
			
			echo $query;
			echo "identificador:";
			echo $identificador;
			$result = $connexion->query($query);
			
			/* si es un mensaje en respuesta a otro actualizamos los datos */
			if ($identificador != 0)
			{
				$query2 = "UPDATE forum SET respuestas=respuestas+1 WHERE ID='$identificador'";
				$result2 = $connexion->query($query2);
				echo $query2;
				Header("Location: forum.php?id=$identificador");
				exit();
			}
			Header("Location: forum-briqueter.php");
		}
	}
?>